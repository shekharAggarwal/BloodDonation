package com.bharatbloodbank.bharatbloodbank.Model;

public class Result {

    public String message_id;
}
