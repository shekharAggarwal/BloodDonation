package com.bharatbloodbank.bharatbloodbank;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.bharatbloodbank.bharatbloodbank.Common.Common;
import com.bharatbloodbank.bharatbloodbank.Model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.Calendar;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import info.hoang8f.widget.FButton;

public class SignIn extends AppCompatActivity {

    //declare var
    MaterialEditText edtPhone, edtOtp, edtName, edtDOB, edtCity, edtDistrict;

    MaterialSpinner Gender, bloodGroup, State;

    FButton btnSignIn, btnVerify, btnName, btnSubmit;
    //database
    FirebaseDatabase database;
    DatabaseReference table_user;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback;
    FirebaseAuth auth;
    private String verificationCode;
    User user;

    ViewFlipper viewFlipper;

    private DatePickerDialog.OnDateSetListener mage;
    TextView timer;
    boolean isRunning = false;

    String age, lastBD;

    String[] gender = {" Male", "Female", "Others"},
            Blood = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"},
            state = {"Rajasthan", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar",
                    "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir",
                    "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
                    "Mizoram", "Nagaland", "Odisha", "Punjab", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
                    "Uttar Pradesh", "Uttarakhand", "West Bengal"};

    CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        //        FirebaseApp.initializeApp(this);
        StartFirebaseLogin();
        ConstraintLayout constraintLayout = findViewById(R.id.root_layout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();


        auth = FirebaseAuth.getInstance();

        viewFlipper = findViewById(R.id.viewFlipper);
        //Activity 1
        edtPhone = findViewById(R.id.edtPhone);

        //Activity 2
        edtOtp = findViewById(R.id.edtOtp);
        timer = findViewById(R.id.timer);

        //Activity 3
        edtName = findViewById(R.id.edtName);
        edtDOB = findViewById(R.id.edtDOB);
        Gender = findViewById(R.id.Gender);
        bloodGroup = findViewById(R.id.bloodGroup);

        //Activity 4
        edtCity = findViewById(R.id.edtCity);
        edtDistrict = findViewById(R.id.edtDistrict);
        State = findViewById(R.id.State);

        //setting data
        Gender.setItems(gender);
        bloodGroup.setItems(Blood);
        State.setItems(state);


        btnSignIn = findViewById(R.id.btnSignIn);
        btnVerify = findViewById(R.id.btnOtp);
        btnName = findViewById(R.id.btnName);
        btnSubmit = findViewById(R.id.btnSubmit);

        edtDOB.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                Calendar ca = Calendar.getInstance();
                int ye = ca.get(Calendar.YEAR);
                int mo = ca.get(Calendar.MONTH);
                int da = ca.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(SignIn.this,
                        android.R.style.Theme_Holo_Dialog_MinWidth,
                        mage,
                        ye, mo, da);
                Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        edtDOB.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    Calendar ca = Calendar.getInstance();
                    int ye = ca.get(Calendar.YEAR);
                    int mo = ca.get(Calendar.MONTH);
                    int da = ca.get(Calendar.DAY_OF_MONTH);

                    DatePickerDialog dialog = new DatePickerDialog(SignIn.this,
                            android.R.style.Theme_Holo_Dialog_MinWidth,
                            mage,
                            ye, mo, da);
                    Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.show();
                }
            }
        });
        mage = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int y, int m, int d) {
                m = m + 1;
                Calendar c = Calendar.getInstance();
                c.set(Calendar.YEAR, y);
                c.set(Calendar.MONTH, m);
                c.set(Calendar.DAY_OF_MONTH, d);
                age = String.valueOf(Common.calAge(c.getTimeInMillis()));
                lastBD = d + "/" + m + "/" + y;
                edtDOB.setText(lastBD);
            }
        };
        database = FirebaseDatabase.getInstance();
        table_user = database.getReference("User");

        if (Common.isConnectedToInternet(getBaseContext())) {
            signIn();
        } else {
            Toast.makeText(this, "Check Internet Connection !!:(", Toast.LENGTH_SHORT).show();
//            return;
        }
    }

    private void signIn() {
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                btnSignIn.setEnabled(false);
                if (Objects.requireNonNull(edtPhone.getText()).toString().isEmpty() || edtPhone.getText().toString().length() != 10) {
                    btnSignIn.setEnabled(true);
                    edtPhone.setError("Enter Correct Phone");
                } else {
                    PhoneAuthProvider.getInstance().verifyPhoneNumber(
                            "+91" + edtPhone.getText().toString(),   // Phone number to verify
                            60,                           // Timeout duration
                            TimeUnit.SECONDS,                // Unit of timeout
                            SignIn.this,              // Activity (for callback binding)
                            mCallback);
                }
            }
        });
    }

    private void verifyOtp() {
        countDownTimer = new CountDownTimer(60000, 1000) {

            @SuppressLint("SetTextI18n")
            public void onTick(long millisUntilFinished) {
                isRunning = true;
                if (millisUntilFinished / 1000 == 10)
                    timer.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                timer.setText("seconds remaining: " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                viewFlipper.showPrevious();
                Toast.makeText(SignIn.this, "Time Out!!", Toast.LENGTH_SHORT).show();
            }
        };
        countDownTimer.start();
        btnVerify.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                btnVerify.setEnabled(false);
                if (Objects.requireNonNull(edtOtp.getText()).toString().isEmpty() || edtOtp.getText().toString().length() != 6) {
                    btnVerify.setEnabled(true);
                    edtOtp.setError("Enter Otp");
                } else {
                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationCode, edtOtp.getText().toString());
                    SigninWithPhone(credential);
                }
            }
        });
    }

    private void enterName() {
        btnName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnName.setEnabled(false);
                if (edtName.getText().toString().isEmpty()) {
                    btnName.setEnabled(true);
                    edtName.setError("Enter Name");
                } else if (edtDOB.getText().toString().isEmpty()) {
                    btnName.setEnabled(true);
                    edtDOB.setError("Enter DOB");
                } else if (Integer.parseInt(age) < 18) {
                    btnName.setEnabled(true);
                    edtDOB.setError("Under 18 Not Allowed");
                } else {
                    viewFlipper.showNext();
                    btnName.setEnabled(true);
                    enterBlood();
                }
            }
        });
    }

    private void enterBlood() {
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnSubmit.setEnabled(false);
                if (edtDistrict.getText().toString().isEmpty()) {
                    btnSubmit.setEnabled(true);
                    edtDistrict.setError("Enter District");
                }
                if (edtCity.getText().toString().isEmpty()) {
                    btnSubmit.setEnabled(true);
                    edtCity.setError("Enter City");
                }
                if (!edtDistrict.getText().toString().isEmpty() && !edtCity.getText().toString().isEmpty()) {
                    sendData();
                }

            }
        });
    }

    private void StartFirebaseLogin() {

        mCallback = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
                Toast.makeText(SignIn.this, "verification completed", Toast.LENGTH_SHORT).show();
                SigninWithPhone(phoneAuthCredential);
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                Log.d("Error", e.getMessage());
//                Toast.makeText(SignIn.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                Toast.makeText(SignIn.this, "verification failed", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(s, forceResendingToken);
                verificationCode = s;
                Toast.makeText(SignIn.this, "OTP sent ", Toast.LENGTH_SHORT).show();
                viewFlipper.showNext();
                btnSignIn.setEnabled(true);
                verifyOtp();

            }
        };
    }

    private void SigninWithPhone(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull final Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            table_user.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.child("+91" + edtPhone.getText().toString()).exists()) {
                                        if (isRunning)
                                            countDownTimer.cancel();
                                        Common.currentUser = dataSnapshot.child("+91" + edtPhone.getText().toString()).getValue(User.class);
                                        Toast.makeText(SignIn.this, "SignIn successfully !", Toast.LENGTH_SHORT).show();
                                        finish();
                                        startActivity(new Intent(SignIn.this, Home.class));
                                    } else {
                                        if (isRunning)
                                            countDownTimer.cancel();
                                        else
                                            viewFlipper.showNext();

                                        btnVerify.setEnabled(true);
                                        viewFlipper.showNext();
                                        enterName();

                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        } else {
                            Toast.makeText(SignIn.this, "Incorrect OTP", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void sendData() {
        final ProgressDialog mDialog = new ProgressDialog(SignIn.this);
        mDialog.setMessage("Please waiting....");
        mDialog.setCancelable(false);
        mDialog.show();
        table_user.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                mDialog.dismiss();
                user = new User(
                        edtPhone.getText().toString(),
                        edtName.getText().toString(),
                        edtDOB.getText().toString(),
                        Gender.getItems().get(Gender.getSelectedIndex()).toString(),
                        bloodGroup.getItems().get(bloodGroup.getSelectedIndex()).toString(),
                        edtDistrict.getText().toString(),
                        edtCity.getText().toString(),
                        State.getItems().get(State.getSelectedIndex()).toString(),
                        " ");
                Common.currentUser = user;
                table_user.child("+91" + edtPhone.getText().toString()).setValue(user);
                Toast.makeText(SignIn.this, "SignIn successfully !", Toast.LENGTH_SHORT).show();
                btnSubmit.setEnabled(true);
                finish();
                startActivity(new Intent(SignIn.this, Home.class));

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}
